﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task7._2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите длинну ребра:");
            int a = Int32.Parse(Console.ReadLine());
            double l = 0;
            double P = 0;
            Cube(out l, out P, a);
            Console.WriteLine($"Обьем куба: {l} м3");
            Console.WriteLine($"Площадь поверхности: {P} м2");
            Console.ReadKey();
        }
        static void Cube(out double Q, out double P, int a)
        {
            Q = Math.Pow(a, 3);
            P = Math.Pow(a, 2) * 6;
        }

        static void Cube2(string[] args)
        {
            Console.WriteLine("Введите длинну ребра:");
            int a = Int32.Parse(Console.ReadLine());
            Console.WriteLine($"Обьем куба: {Math.Pow(a, 3)} м3");
            Console.WriteLine($"Площадь поверхности: {Math.Pow(a, 2) * 6} м2");
            Console.ReadKey();
        }


    }

}